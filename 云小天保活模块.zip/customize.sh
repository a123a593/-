#!/system/bin/sh
# ============================================================
#  安装脚本
#  由安装器 source 执行
# ============================================================

BASE=/data/local/tmp/ax_yxt

ui_print ""
ui_print "****************************************"
ui_print "   云小天保活模块  v1:0:0"
ui_print "   保持云小天 shell 不被杀掉"
ui_print "****************************************"
ui_print ""

sleep 1
ui_print "- 创建工作目录 $BASE"
mkdir -p "$BASE" 2>/dev/null
chmod 777 "$BASE" 2>/dev/null

ui_print "- 写入默认配置 config.sh"
if [ ! -f "$BASE/config.sh" ]; then
cat > "$BASE/config.sh" << 'CONFEOF'
# ============ 云小天保活模块 配置（改完立即生效，无需重装） ============
# 目标 App 包名
TARGET_PKG="com.yunxiaotian.app"

# shell 通道进程名，任一存活即视为在线
# 常见值：axeron_server / shizuku_server
SHELL_PROCS="axeron_server shizuku_server"

# 检测间隔（秒）
INTERVAL=5

# 云小天被杀后自动拉起 1/0
AUTO_START_APP=1

# 维持电池优化白名单 1/0
KEEP_WHITELIST=1

# 维持无线调试常开（让 shell 通道重启后能自动恢复）1/0
# 部分机型会回滚该设置，无效时可关闭
KEEP_WIRELESS_DEBUG=1
ADB_PORT=5555

# 白名单与无线调试每多少轮执行一次
# 这两个调用较重，不建议过频
HEAVY_EVERY=12

# 自动补授权限 1/0
GRANT_MISSING_PERMS=0

# 授权清单自愈 1/0
AUTO_HEAL_PERM=1

# 心跳日志间隔（秒），0 = 关闭
# 需要定期确认存活可设为 60
HEARTBEAT=0

# 日志最大行数
LOG_MAX=800
CONFEOF
fi

ui_print "- 写入用户指令表 custom_cmds.sh"
if [ ! -f "$BASE/custom_cmds.sh" ]; then
cat > "$BASE/custom_cmds.sh" << 'CMDEOF'
# ============ 你的专属指令（每行一条，等价于 adb shell 一条命令） ============
# 以 # 开头或空行会被跳过。模块每一轮循环都会执行一遍。
# 例：
# settings put global xxx 1
# am start -n com.xxx/.MainActivity
CMDEOF
fi

rm -f "$BASE/OFF" 2>/dev/null

ui_print "- 备份 AxManager 授权清单（授权自愈用）"
if [ -f /data/user_de/0/com.android.shell/axeron/ax_permission.json ]; then
  cp /data/user_de/0/com.android.shell/axeron/ax_permission.json "$BASE/ax_permission.json.bak" 2>/dev/null
  ui_print "  已备份 ax_permission.json"
else
  ui_print "  未找到 ax_permission.json（稍后模块会自动补备份）"
fi

ui_print "- 设置脚本权限"
chmod 755 "$MODPATH"/*.sh 2>/dev/null

# 安装后启动守护进程
ui_print "- 启动守护进程"
if [ -f "$BASE/worker.pid" ]; then
  OW=$(cat "$BASE/worker.pid" 2>/dev/null)
  [ -n "$OW" ] && kill "$OW" 2>/dev/null
  rm -f "$BASE/worker.pid"
fi
rm -f "$BASE/OFF" 2>/dev/null
# 清除残留的禁用/卸载标记
rm -f "$MODPATH/disable" "$MODPATH/remove" 2>/dev/null
# 延后启动，避开安装收尾时的进程清理
setsid /system/bin/sh -c "sleep 25; exec /system/bin/sh '$BASE/ax_run.sh'" >/dev/null 2>&1 &
ui_print "  守护进程将在安装完成后自动启动"

sleep 1
ui_print ""
ui_print "安装完成：重启后自动生效"
ui_print "开关：AxManager 里点本模块的 Action 按钮"
ui_print "手动关闭：touch $BASE/OFF"
ui_print "卸载时会自动撤销白名单/权限等全部改动"
ui_print ""
