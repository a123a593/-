# 云小天保活模块

作者：云上天·阿U
版本：1:0:0
模块 id：ax_yunxiaotian_keepalive

AxManager / Axeron 插件。维持 shell 通道与云小天进程存活，
并监控 AxManager 的权限清单，被移除时自动写回。

---

## 文件说明

```
module.prop     模块信息
customize.sh    安装时执行：初始化配置、备份权限清单、启动守护进程
service.sh      开机自启
action.sh       Action 按钮：开 / 关 + 打印状态
ax_run.sh       守护进程主体
ax_ctl.sh       控制脚本 start | stop | restart | status | log | runonce
uninstall.sh    卸载清理
banner.png      图标
```

模块目录：`/data/user_de/0/com.android.shell/axeron/plugins/ax_yunxiaotian_keepalive/`
运行数据：`/data/local/tmp/ax_yxt/`

## 安装

AxManager 里从本地安装 zip。装完守护进程会自动启动（约 25 秒后）。

## 运行逻辑

守护进程每 5 秒一轮，做这些事：

1. 检测 shell 通道进程（axeron_server / shizuku_server），不在就尝试重启
2. 检测云小天进程，不在就 am start 拉起
3. 检查权限清单里有没有云小天，没有就写回
4. 白名单与无线调试按 HEAVY_EVERY 降频执行
5. 执行用户自定义指令表

## 配置

`/data/local/tmp/ax_yxt/config.sh`，改完下一轮生效，不用重装。

```sh
TARGET_PKG="com.yunxiaotian.app"   # 目标 App
SHELL_PROCS="axeron_server shizuku_server"
INTERVAL=5                          # 检测间隔（秒）
AUTO_START_APP=1                    # 被杀后自动拉起
KEEP_WHITELIST=1                    # 维持电池优化白名单
KEEP_WIRELESS_DEBUG=1               # 维持无线调试常开
ADB_PORT=5555
HEAVY_EVERY=12                      # 白名单/无线调试每多少轮执行一次
GRANT_MISSING_PERMS=0               # 自动补授权限
AUTO_HEAL_PERM=1                    # 权限清单自愈
HEARTBEAT=0                         # 心跳日志间隔（秒），0 = 关闭
LOG_MAX=800
```

用户自定义指令写在 `/data/local/tmp/ax_yxt/custom_cmds.sh`，一行一条（`#` 开头和空行会跳过），每轮执行一遍。

## 开关

点 AxManager 里本模块的 Action 按钮，或：

```sh
sh /data/user_de/0/com.android.shell/axeron/plugins/ax_yunxiaotian_keepalive/ax_ctl.sh start
sh .../ax_ctl.sh stop
sh .../ax_ctl.sh status
sh .../ax_ctl.sh log
```

临时关闭（模块保留）：`touch /data/local/tmp/ax_yxt/OFF`
关闭插件或点卸载后，守护进程会自己退出，不会残留。

## 卸载

AxManager 里卸载，会执行 `uninstall.sh`：

停掉守护进程 → 撤销电池优化白名单 → 复位 appops →
撤销授予过的权限 → 删除 `/data/local/tmp/ax_yxt`。

如果 AxManager 没触发，手动执行一次：

```sh
sh /data/user_de/0/com.android.shell/axeron/plugins/ax_yunxiaotian_keepalive/uninstall.sh
```

## 说明

- 权限清单自愈只能恢复"已经存在过"的授权（清单里条目被移除的情况）。
  在 AxManager 界面上手动关闭开关，不会写入该文件，模块无法感知。
- 守护进程被系统清理后需要重新启动，重启设备或点 Action 均可。
