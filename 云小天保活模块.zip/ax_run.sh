#!/system/bin/sh
# ============================================================
#  守护进程
#  由 service.sh / ax_ctl.sh 启动
# ============================================================
MODDIR=${0%/*}
BASE=/data/local/tmp/ax_yxt
CONF=$BASE/config.sh
CMDS=$BASE/custom_cmds.sh
OFF=$BASE/OFF
LOG=$BASE/guardian.log
PIDF=$BASE/worker.pid
GRANTED=$BASE/granted.list

mkdir -p "$BASE" 2>/dev/null

# 默认值
TARGET_PKG="com.yunxiaotian.app"
SHELL_PROCS="axeron_server shizuku_server"
INTERVAL=5
AUTO_START_APP=1
KEEP_WHITELIST=1
KEEP_WIRELESS_DEBUG=1
ADB_PORT=5555
# 白名单与无线调试每多少轮执行一次
HEAVY_EVERY=12
GRANT_MISSING_PERMS=0
AUTO_HEAL_PERM=1
HEARTBEAT=0
LOG_MAX=800

[ -f "$CONF" ] && . "$CONF"

log() { echo "$(date '+%m-%d %H:%M:%S') $*" >> "$LOG" 2>/dev/null; }

trim_log() {
  [ -f "$LOG" ] || return 0
  n=$(wc -l < "$LOG" 2>/dev/null)
  if [ -n "$n" ] && [ "$n" -gt "$LOG_MAX" ] 2>/dev/null; then
    tail -n "$LOG_MAX" "$LOG" > "$LOG.tmp" 2>/dev/null && mv "$LOG.tmp" "$LOG"
  fi
}

# shell 通道检测 / 复活
shell_channel_alive() {
  for p in $SHELL_PROCS; do
    pidof "$p" >/dev/null 2>&1 && return 0
  done
  return 1
}

revive_shell_channel() {
  # 重启 axeron 服务
  if [ -n "$AXERONLIB" ] && [ -f "$AXERONLIB/libaxeron.so" ]; then
    "$AXERONLIB/libaxeron.so" >/dev/null 2>&1 &
    log "试图重启 axeron_server ($AXERONLIB/libaxeron.so)"
    sleep 1
  fi
  # 常见启动脚本位置
  for s in /data/local/tmp/start.sh \
           /data/local/tmp/shizuku/start.sh \
           /sdcard/Android/data/moe.shizuku.privileged.api/start.sh; do
    if [ -f "$s" ]; then
      sh "$s" >/dev/null 2>&1
      log "试图执行启动脚本 $s"
    fi
  done
}

# 云小天进程保活
app_alive() { pidof "$TARGET_PKG" >/dev/null 2>&1; }

start_app() {
  ACT=$(cmd package resolve-activity --brief -c android.intent.category.LAUNCHER "$TARGET_PKG" 2>/dev/null | tail -1)
  case "$ACT" in
    ""|*"No activity found"*|*Exception*) ACT="" ;;
  esac
  if [ -n "$ACT" ]; then
    am start -n "$ACT" >/dev/null 2>&1
  else
    monkey -p "$TARGET_PKG" -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1
  fi
}

# .5 授权自愈：把被移除的云小天授权写回去
# ax_permission.json 属主为 shell，可读写
AXPERM=/data/user_de/0/com.android.shell/axeron/ax_permission.json
AXPERM_BAK=$BASE/ax_permission.json.bak

heal_permission() {
  [ -f "$AXPERM" ] || return 0
  # 备份不存在则创建
  [ -f "$AXPERM_BAK" ] || cp "$AXPERM" "$AXPERM_BAK" 2>/dev/null
  grep -q "$TARGET_PKG" "$AXPERM" 2>/dev/null && return 0

  # 首选精准插入：只把目标包塞回数组头，不动其它应用的授权
  U=$(cmd package list packages -U 2>/dev/null | grep "$TARGET_PKG" | head -1 | sed 's/.*uid://')
  if [ -n "$U" ]; then
    sed -i "s|\"packages\":\[|\"packages\":[{\"uid\":$U,\"flags\":2,\"packages\":[\"$TARGET_PKG\"]},|" "$AXPERM" 2>/dev/null
    if grep -q "$TARGET_PKG" "$AXPERM" 2>/dev/null; then
      log "授权自愈：已把 $TARGET_PKG (uid=$U) 写回权限清单"
      return 0
    fi
  fi

  # 精准插入失败，退回整文件还原
  if [ -f "$AXPERM_BAK" ]; then
    cp "$AXPERM_BAK" "$AXPERM" 2>/dev/null
    log "授权自愈：精准插入失败，已用备份整文件还原"
  else
    log "授权自愈失败：目标文件与备份都不可用"
  fi
}

# 电池优化白名单
ensure_whitelist() {
  if ! dumpsys deviceidle whitelist 2>/dev/null | grep -q "$TARGET_PKG"; then
    if dumpsys deviceidle whitelist +"$TARGET_PKG" >/dev/null 2>&1; then
      log "加入电池优化白名单 $TARGET_PKG"
      echo "$TARGET_PKG" >> "$GRANTED"
    fi
  fi
}

# 无线调试维持（shell 通道重启的前提）
keep_wireless_debug() {
  settings put global adb_wifi_enabled 1 >/dev/null 2>&1
  setprop service.adb.tcp.port "$ADB_PORT" >/dev/null 2>&1
}

# 用户自定义指令表
run_custom_cmds() {
  [ -s "$CMDS" ] || return 0
  while IFS= read -r line || [ -n "$line" ]; do
    case "$line" in ''|'#'*) continue ;; esac
    sh -c "$line" >> "$LOG" 2>&1
  done < "$CMDS"
}

# ============================================================
echo $$ > "$PIDF"
log "===== worker 启动 pid=$$ ====="
BEAT=0
TICK=0

while true; do
  # 停止开关
  if [ -f "$OFF" ] || [ -f "$MODDIR/disable" ] || [ -f "$MODDIR/remove" ]; then
    log "检测到 OFF/disable/remove 标记，worker 退出"
    rm -f "$PIDF"
    exit 0
  fi

  # 重读配置
  [ -f "$CONF" ] && . "$CONF"

  # shell 通道
  if ! shell_channel_alive; then
    log "shell 通道离线，尝试复活"
    revive_shell_channel
    if shell_channel_alive; then
      log "shell 通道已恢复"
    else
      log "复活失败（可能需要手动在 AxManager 里重新 Start）"
    fi
  fi

  # 云小天本体
  if [ "$AUTO_START_APP" = 1 ] && ! app_alive; then
    log "云小天进程不在，拉起"
    start_app
  fi

  # .5 授权自愈（模块能做到"自动打开"的核心）
  [ "$AUTO_HEAL_PERM" = 1 ] && heal_permission

  # 重活降频：白名单与无线调试每 HEAVY_EVERY 轮才查一次
  #     dumpsys / settings put 都是跨进程调用，每 5 秒跑一次非常费电
  TICK=$((TICK + 1))
  if [ $((TICK % HEAVY_EVERY)) -eq 0 ] 2>/dev/null; then
    [ "$KEEP_WHITELIST" = 1 ] && ensure_whitelist
    [ "$KEEP_WIRELESS_DEBUG" = 1 ] && keep_wireless_debug
  fi

  # 用户指令
  run_custom_cmds

  # 心跳日志（HEARTBEAT=0 表示彻底关闭心跳，日志只在出事时才写）
  if [ "${HEARTBEAT:-0}" -gt 0 ] 2>/dev/null; then
    BEAT=$((BEAT + INTERVAL))
    if [ "$BEAT" -ge "$HEARTBEAT" ] 2>/dev/null; then
      BEAT=0
      if shell_channel_alive; then CS=在线; else CS=离线; fi
      if app_alive; then AS=运行中; else AS=已退出; fi
      log "心跳 | shell通道=$CS | 云小天=$AS"
    fi
  fi

  trim_log
  sleep "$INTERVAL"
done
