#!/system/bin/sh
# ============================================================
#  开机自启
# ============================================================
MODDIR=${0%/*}
BASE=/data/local/tmp/ax_yxt
OFF=$BASE/OFF

mkdir -p "$BASE" 2>/dev/null
chmod 777 "$BASE" 2>/dev/null

# 等待系统就绪
for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20; do
  [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ] && break
  sleep 3
done

# 已关闭 / 已禁用 / 已标记卸载时不启动
[ -f "$OFF" ] && exit 0
[ -f "$MODDIR/disable" ] && exit 0
[ -f "$MODDIR/remove" ] && exit 0

# 已在运行则不重复启动
if [ -f "$BASE/worker.pid" ]; then
  p=$(cat "$BASE/worker.pid" 2>/dev/null)
  [ -n "$p" ] && kill -0 "$p" 2>/dev/null && exit 0
fi

setsid /system/bin/sh "$MODDIR/ax_run.sh" >/dev/null 2>&1 &
