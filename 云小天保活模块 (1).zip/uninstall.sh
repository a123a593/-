#!/system/bin/sh
# ============================================================
#  卸载清理
#  逐条撤销模块做过的改动
# ============================================================
MODDIR=${0%/*}
BASE=/data/local/tmp/ax_yxt
CONF=$BASE/config.sh
GRANTED=$BASE/granted.list

[ -f "$CONF" ] && . "$CONF"
: ${TARGET_PKG:=com.yunxiaotian.app}

# 停掉守护进程
touch "$BASE/OFF" 2>/dev/null
if [ -f "$BASE/worker.pid" ]; then
  p=$(cat "$BASE/worker.pid" 2>/dev/null)
  [ -n "$p" ] && { kill "$p" 2>/dev/null; sleep 1; kill -9 "$p" 2>/dev/null; }
fi

# 撤销电池优化白名单
dumpsys deviceidle whitelist -"$TARGET_PKG" >/dev/null 2>&1

# 复位 appops
for op in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND; do
  cmd appops set "$TARGET_PKG" "$op" default >/dev/null 2>&1
done

# 撤销授予过的运行时权限
if [ -f "$GRANTED" ]; then
  while IFS= read -r perm; do
    case "$perm" in
      *.*) pm revoke "$TARGET_PKG" "$perm" >/dev/null 2>&1 ;;
    esac
  done < "$GRANTED"
fi

# 清除运行痕迹
rm -rf "$BASE" 2>/dev/null

echo "云小天保活模块已卸载，所有改动已撤销"
