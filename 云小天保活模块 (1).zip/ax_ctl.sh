#!/system/bin/sh
# ============================================================
#  控制脚本
#  用法: ax_ctl.sh start|stop|restart|status|log|runonce
# ============================================================
MODDIR=${0%/*}
BASE=/data/local/tmp/ax_yxt
CONF=$BASE/config.sh
OFF=$BASE/OFF
PIDF=$BASE/worker.pid

mkdir -p "$BASE" 2>/dev/null
[ -f "$CONF" ] && . "$CONF"
: ${TARGET_PKG:=com.yunxiaotian.app}
: ${SHELL_PROCS:="axeron_server shizuku_server"}

worker_pid() {
  [ -f "$PIDF" ] || return 1
  p=$(cat "$PIDF" 2>/dev/null)
  [ -n "$p" ] && kill -0 "$p" 2>/dev/null && { echo "$p"; return 0; }
  return 1
}

do_start() {
  # 已禁用或已标记卸载时不启动
  if [ -f "$MODDIR/disable" ]; then
    echo "[!] 模块已被禁用，拒绝启动"
    return 1
  fi
  if [ -f "$MODDIR/remove" ]; then
    echo "[!] 模块已被标记卸载，拒绝启动"
    return 1
  fi
  rm -f "$OFF" 2>/dev/null
  if p=$(worker_pid); then
    echo "[=] 守护进程已在运行 (pid=$p)"
  else
    setsid /system/bin/sh "$MODDIR/ax_run.sh" >/dev/null 2>&1 &
    sleep 1
    if p=$(worker_pid); then
      echo "[+] 守护进程已启动 (pid=$p)"
    else
      echo "[!] 启动失败，请检查 AxManager 是否已获得 shell 权限"
    fi
  fi
}

do_stop() {
  touch "$OFF" 2>/dev/null
  sleep 1
  if p=$(worker_pid); then
    kill "$p" 2>/dev/null
    sleep 1
    kill -9 "$p" 2>/dev/null
  fi
  rm -f "$PIDF"
  echo "[x] 守护进程已停止（模块仍安装，配置与日志保留）"
}

do_status() {
  echo "===== 云小天保活模块 状态 ====="
  if [ -f "$OFF" ]; then echo "模块开关 : 已关闭 (OFF)"; else echo "模块开关 : 已开启"; fi
  if p=$(worker_pid); then echo "守护进程 : 运行中 (pid=$p)"; else echo "守护进程 : 未运行"; fi

  echo "--- shell 通道 ---"
  found=0
  for x in $SHELL_PROCS; do
    if pidof "$x" >/dev/null 2>&1; then
      echo "  [在线] $x (pid=$(pidof $x))"
      found=1
    else
      echo "  [离线] $x"
    fi
  done
  [ "$found" = 0 ] && echo "  => 当前没有任何 shell 通道进程"

  echo "--- 目标 App ---"
  if pidof "$TARGET_PKG" >/dev/null 2>&1; then
    echo "  [运行中] $TARGET_PKG (pid=$(pidof $TARGET_PKG))"
  else
    echo "  [未运行] $TARGET_PKG"
  fi

  echo "--- 后台白名单 ---"
  if dumpsys deviceidle whitelist 2>/dev/null | grep -q "$TARGET_PKG"; then
    echo "  [已加入] 电池优化白名单"
  else
    echo "  [未加入] 电池优化白名单"
  fi

  echo "--- 最近日志 ---"
  if [ -f "$BASE/guardian.log" ]; then tail -n 12 "$BASE/guardian.log"; else echo "  (无日志)"; fi
}

case "$1" in
  start)   do_start ;;
  stop)    do_stop ;;
  restart) do_stop; sleep 1; do_start ;;
  status)  do_status ;;
  log)     tail -n 60 "$BASE/guardian.log" 2>/dev/null ;;
  runonce)
    rm -f "$OFF"
    setsid /system/bin/sh "$MODDIR/ax_run.sh" >/dev/null 2>&1 &
    echo "[+] 已强制启动"
    ;;
  *) echo "用法: $0 start|stop|restart|status|log|runonce" ;;
esac
