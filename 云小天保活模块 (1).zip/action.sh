#!/system/bin/sh
# ============================================================
#  Action 按钮
#  按实际状态切换开关
# ============================================================
MODDIR=${0%/*}
BASE=/data/local/tmp/ax_yxt
PIDF=$BASE/worker.pid

mkdir -p "$BASE" 2>/dev/null

RUNNING=0
if [ -f "$PIDF" ]; then
  p=$(cat "$PIDF" 2>/dev/null)
  [ -n "$p" ] && kill -0 "$p" 2>/dev/null && RUNNING=1
fi

if [ "$RUNNING" = 1 ]; then
  echo ">>> 正在关闭云小天保活模块..."
  sh "$MODDIR/ax_ctl.sh" stop
else
  echo ">>> 正在开启云小天保活模块（立即生效，无需重启）..."
  sh "$MODDIR/ax_ctl.sh" start
fi

echo ""
sh "$MODDIR/ax_ctl.sh" status
